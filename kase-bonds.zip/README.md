# Рейтинг облигаций KASE

- `index.html` — дашборд, читает `data.json` рядом с собой.
- `data.json` — сейчас демо (`"demo": true`). Реальный файл создаёт `scripts/update_data.py`.
- `scripts/issuers.json` — список эмитентов и ручная оценка отчётности (good / medium / weak).
- `.github/workflows/update.yml` — запуск парсера каждые 30 минут в торговые часы.

Запуск: загрузите папку в репозиторий GitHub, включите Pages (ветка main, корень), в Actions запустите «Обновление данных KASE» вручную.

Перед первым запуском проверьте `SOURCES` и `COLUMNS` в `scripts/update_data.py` по реальным страницам kase.kz.
Веса и пороги: блок `CFG` в начале скрипта `index.html`, веса также меняются ползунками на странице.
